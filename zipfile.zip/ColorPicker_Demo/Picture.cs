﻿using System.Drawing;

namespace ColorPicker_Demo
{
    public class Picture
    {
        Sorter sorter = new Sorter();
        private string path;

        public string Path
        {
            get { return path; }
            set { path = value; }
        }
        private Image pictureTaken;

        public Image PictureTaken
        {
            get { return pictureTaken; }
            set { pictureTaken = value; }
        }


        public Picture()
        {
            Path = TakePicture(this);
            Bitmap picBitMap = new Bitmap(Path);
            sorter.Classify(picBitMap);
        }

        public string TakePicture(Picture pic)
        {

            string pathway = @"C: \Users\Kenn5073\Desktop\RPB.png";
            return pathway;
        }
    }
}