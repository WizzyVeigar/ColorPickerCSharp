﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Threading.Tasks;

namespace ColorPicker_Demo
{
    public class Sorter
    {
        public List<Color> colorList = new List<Color>(); //prob needs to be in sorter

        public void Classify(Bitmap bitMapPic)
        {
            int x, y;

            //List for colors in the image
            // Loop through the images pixels to get color.

            for (x = 0; x < bitMapPic.Width; x++)
            {
                for (y = 0; y < bitMapPic.Height; y++)
                {
                    System.Drawing.Color pixelColor = bitMapPic.GetPixel(x, y);

                    float hue = pixelColor.GetHue();
                    float sat = pixelColor.GetSaturation();
                    float lgt = pixelColor.GetBrightness();

                    if (lgt < 0.2)
                    {
                        Color black = new Color("Black");
                        colorList.Add(black);
                    }
                    if (lgt > 0.8)
                    {
                        Color white = new Color("White");
                        colorList.Add(white);
                    }

                    if (sat < 0.25)
                    {
                        Color grey = new Color("Grey");
                        colorList.Add(grey);
                    }

                    if (hue < 30)
                    {
                        Color red = new Color("Red");
                        colorList.Add(red);
                    }
                    if (hue < 90)
                    {
                        Color yellow = new Color("Yellow");
                        colorList.Add(yellow);
                    }
                    if (hue < 150)
                    {
                        Color green = new Color("Green");
                        colorList.Add(green);
                    }
                    if (hue < 210)
                    {
                        Color cyan = new Color("Cyan");
                        colorList.Add(cyan);
                    }
                    if (hue < 270)
                    {
                        Color blue = new Color("Blue");
                        colorList.Add(blue);
                    }
                    if (hue < 330)
                    {
                        Color magenta = new Color("Magenta");
                        colorList.Add(magenta);
                    }
                }
            }
        }

        public void GetAllColors()
        {

            Color color = new Color("Blue");
            var groupedcolors = colorList.GroupBy(colorList => color.Name);
            //colorList.FindAll(color.Name == "Black");
            Console.WriteLine("hello there");
            Console.WriteLine(groupedcolors.ToString());
        }
    }
}
