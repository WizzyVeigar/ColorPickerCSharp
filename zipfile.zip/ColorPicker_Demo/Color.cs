﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ColorPicker_Demo
{
    public class Color : ColorsSC
    {
        public Color(string name) : base(name)
        {
        }
        
    }
}
